Main is in file: linked_list.java
