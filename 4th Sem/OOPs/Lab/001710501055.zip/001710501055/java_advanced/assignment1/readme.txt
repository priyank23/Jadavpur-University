Main is in file: QuoteOfTheDay.java
It is a package.
