Main is in file: 5.java
The .txt file contains the paragraph that has been parsed by the program.
