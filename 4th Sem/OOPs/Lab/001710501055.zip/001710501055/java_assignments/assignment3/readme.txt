Main is in file: 3.java
Its a package
