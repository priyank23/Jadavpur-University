Main is in file: doctor.java
It is a package.
The doctor.txt file contains doctors list.
