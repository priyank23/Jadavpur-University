Main is in file: student.java
