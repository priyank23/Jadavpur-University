Main is in file: QuoteOfTheDay.java
